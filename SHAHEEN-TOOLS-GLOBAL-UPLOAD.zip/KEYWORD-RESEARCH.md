# SHAHEEN Tools — keyword and content map

Keyword themes are mapped to one relevant landing page each to avoid keyword cannibalization. These are intent-based targets, not guaranteed search-volume or ranking estimates. Confirm country-specific demand in Google Search Console and Keyword Planner after launch.

| Page | Primary query | Supporting queries |
|---|---|---|
| /tools/word-counter.html | word counter | word counter, character counter, sentence counter |
| /tools/qr-code-generator.html | QR code generator | QR code generator, create QR code, free QR maker |
| /tools/image-compressor.html | image compressor | image compressor, compress image online, reduce image size |
| /tools/image-resizer.html | image resizer | image resizer, resize image online, photo dimensions |
| /tools/image-to-pdf.html | image to PDF | image to PDF, JPG to PDF, PNG to PDF |
| /tools/pdf-merge.html | merge PDF | merge PDF, combine PDF files, PDF merger |
| /tools/pdf-split.html | split PDF | split PDF, extract PDF pages, PDF page extractor |
| /tools/pdf-rotate.html | rotate PDF | rotate PDF, rotate PDF pages online |
| /tools/percentage-calculator.html | percentage calculator | percentage calculator, percentage increase calculator |
| /tools/unit-converter.html | unit converter | unit converter, length converter, kg to lbs, celsius to fahrenheit |
| /tools/json-formatter.html | JSON formatter | JSON formatter, JSON validator, JSON beautifier |
| /tools/base64-tool.html | Base64 encoder | Base64 encoder, Base64 decoder, Base64 converter |
| /tools/url-encoder.html | URL encoder | URL encoder, URL decoder, percent encoding |
| /tools/password-generator.html | random password generator | random password generator, secure password generator |
| /tools/uuid-generator.html | UUID generator | UUID generator, GUID generator, UUID v4 |
| /tools/timestamp-converter.html | Unix timestamp converter | Unix timestamp converter, epoch converter, timestamp to date |
| /tools/date-calculator.html | days between dates | days between dates, date calculator, date difference calculator |
| /tools/age-calculator.html | age calculator | age calculator, calculate age, date of birth calculator |
| /tools/text-case-converter.html | uppercase converter | uppercase converter, lowercase converter, title case converter |
| /tools/duplicate-line-remover.html | remove duplicate lines | remove duplicate lines, duplicate line remover, deduplicate text |
| /tools/random-number-generator.html | random number generator | random number generator, random integer generator |
| /tools/color-converter.html | HEX to RGB | HEX to RGB, RGB to HEX, color converter |
| /tools/csv-to-json.html | CSV to JSON | CSV to JSON, convert CSV to JSON online |
| /tools/html-encoder.html | HTML encoder | HTML encoder, HTML decoder, HTML entity converter |
| /tools/calculator.html | online calculator | online calculator, basic calculator, free calculator |

## Content rules
- Keep each page's title, description, H1 and visible functionality specific to that tool.
- Add original instructions, examples, limitations and tested output examples as real user needs emerge.
- Do not create doorway pages, hidden keyword blocks or repeated city/country pages.
- Track queries, clicks, impressions and indexing in Search Console; update pages based on actual data.
- No ranking, AI Overview, traffic or revenue outcome is guaranteed.
